import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:stonework_construction/app/app.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('app boots', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: StoneworkApp()));
    await tester.pumpAndSettle();
    expect(find.textContaining('StoneWork'), findsWidgets);
  });
}
