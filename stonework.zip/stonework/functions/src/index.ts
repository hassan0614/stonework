import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
admin.initializeApp();

export const apiHealth = functions.https.onRequest((_req, res) => {
  res.status(200).json({ ok: true, service: 'stonework-functions', timestamp: new Date().toISOString() });
});

import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

admin.initializeApp();

interface EstimateData {
  areaSqFt?: number;
  baseRatePerSqFt?: number;
  locationMultiplier?: number;
  qualityMultiplier?: number;
  contingencyRate?: number;
  permitFees?: number;
}

export const estimateCost = functions.https.onCall((data: EstimateData, context) => {
  const areaSqFt = Number(data?.areaSqFt ?? 0);
  const baseRatePerSqFt = Number(data?.baseRatePerSqFt ?? 4200);
  const locationMultiplier = Number(data?.locationMultiplier ?? 1.0);
  const qualityMultiplier = Number(data?.qualityMultiplier ?? 1.0);
  const contingencyRate = Number(data?.contingencyRate ?? 0.1);
  const permitFees = Number(data?.permitFees ?? 250000);

  const base = areaSqFt * baseRatePerSqFt;
  const adjusted = base * locationMultiplier * qualityMultiplier;
  const contingency = adjusted * contingencyRate;
  const total = adjusted + contingency + permitFees;

  return { base, adjusted, contingency, permitFees, total };
});

interface RoleData {
  role?: string;
}

export const setUserRole = functions.https.onCall(async (data: RoleData, context) => {
  if (!context?.auth?.uid) throw new functions.https.HttpsError('unauthenticated', 'Login required');

  const role = String(data?.role ?? 'buyer');

  await admin.auth().setCustomUserClaims(context.auth.uid, { role });
  await admin.firestore().collection('users').doc(context.auth.uid).set({ role }, { merge: true });

  return { ok: true, role };
});