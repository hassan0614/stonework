import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/app_state.dart';
import '../core/utils.dart';
import '../data/mock/mock_data.dart';
import '../domain/models.dart';

class SplashGateScreen extends ConsumerStatefulWidget {
  const SplashGateScreen({super.key});

  @override
  ConsumerState<SplashGateScreen> createState() => _SplashGateScreenState();
}

class _SplashGateScreenState extends ConsumerState<SplashGateScreen> {
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Theme.of(context).colorScheme.primary, Theme.of(context).colorScheme.secondaryContainer],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.construction_rounded, color: Colors.white, size: 92),
                SizedBox(height: 18),
                Text('Stone Work Construction', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
                SizedBox(height: 8),
                Text('Reliable property and contractor workflows', style: TextStyle(color: Colors.white70)),
                SizedBox(height: 20),
                CircularProgressIndicator(color: Colors.white),
              ],
            ),
          ),
        ),
      );
}

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final controller = PageController();
  int index = 0;
  final pages = const [
    (Icons.apartment_rounded, 'Buy, sell, rent, and build', 'Manage buyers, sellers, dealers, and contractors in one place.'),
    (Icons.people_alt_rounded, 'Search real contacts', 'Browse the user directory, filter roles, and contact people by email, phone, or chat.'),
    (Icons.chat_rounded, 'Simple short-term chat', 'Start a conversation instantly. Chats auto-expire after 7 days to keep storage light.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(actions: [TextButton(onPressed: () async { await ref.read(appStateProvider).markOnboardingSeen(); if (!mounted) return; context.go('/login'); }, child: const Text('Skip'))]),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Expanded(
              child: PageView.builder(
                controller: controller,
                itemCount: pages.length,
                onPageChanged: (value) => setState(() => index = value),
                itemBuilder: (context, i) {
                  final page = pages[i];
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircleAvatar(radius: 70, backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: Icon(page.$1, size: 68)),
                      const SizedBox(height: 28),
                      Text(page.$2, textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 12),
                      Text(page.$3, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
                    ],
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                pages.length,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: i == index ? 26 : 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: i == index ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.outlineVariant,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 22),
            FilledButton(
              onPressed: () async {
                if (index == pages.length - 1) {
                  await ref.read(appStateProvider).markOnboardingSeen();
                  if (!mounted) return;
                  context.go('/login');
                } else {
                  controller.nextPage(duration: const Duration(milliseconds: 250), curve: Curves.easeInOut);
                }
              },
              child: Text(index == pages.length - 1 ? 'Get started' : 'Next'),
            ),
          ],
        ),
      ),
    );
  }
}

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final formKey = GlobalKey<FormState>();
  final email = TextEditingController(text: 'hassan@example.com');
  final password = TextEditingController(text: '123456');
  bool hidePassword = true;

  @override
  Widget build(BuildContext context) {
    final appState = ref.watch(appStateProvider);
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: Card(
            margin: const EdgeInsets.all(24),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Form(
                key: formKey,
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    const SizedBox(height: 8),
                    const Icon(Icons.foundation_rounded, size: 72),
                    const SizedBox(height: 12),
                    Text('Welcome back', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Text('Log in with your email and password.', style: Theme.of(context).textTheme.bodyLarge),
                    const SizedBox(height: 22),
                    TextFormField(controller: email, decoration: const InputDecoration(labelText: 'Email'), validator: AppUtils.email),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: password,
                      obscureText: hidePassword,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => hidePassword = !hidePassword),
                          icon: Icon(hidePassword ? Icons.visibility_off : Icons.visibility),
                        ),
                      ),
                      validator: AppUtils.password,
                    ),
                    if (appState.authError != null) ...[
                      const SizedBox(height: 12),
                      Text(appState.authError!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                    ],
                    const SizedBox(height: 18),
                    FilledButton(
                      onPressed: appState.authBusy
                          ? null
                          : () async {
                              if (!formKey.currentState!.validate()) return;
                              try {
                                await ref.read(appStateProvider).login(email.text.trim(), password.text);
                                if (!mounted) return;
                                if (ref.read(appStateProvider).user?.role == null) {
                                  context.go('/role');
                                } else {
                                  context.go('/app/home');
                                }
                              } catch (_) {}
                            },
                      child: Text(appState.authBusy ? 'Please wait...' : 'Login'),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton(onPressed: () => context.go('/register'), child: const Text('Create account')),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final formKey = GlobalKey<FormState>();
  final fullName = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final confirmPassword = TextEditingController();
  final phone = TextEditingController(text: AppUtils.countries.first.dialCode);
  CountryOption country = AppUtils.countries.first;
  UserRole role = UserRole.buyer;
  bool hidePassword = true;
  bool hideConfirmPassword = true;

  @override
  Widget build(BuildContext context) {
    final appState = ref.watch(appStateProvider);
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 560),
          child: Card(
            margin: const EdgeInsets.all(24),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Form(
                key: formKey,
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Text('Create account', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    const Text('Register once, choose a role, and appear in the contact directory.'),
                    const SizedBox(height: 20),
                    TextFormField(controller: fullName, decoration: const InputDecoration(labelText: 'Full name'), validator: (v) => AppUtils.requiredField(v, 'Full name')),
                    const SizedBox(height: 12),
                    TextFormField(controller: email, decoration: const InputDecoration(labelText: 'Email'), validator: AppUtils.email),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<UserRole>(
                      value: role,
                      decoration: const InputDecoration(labelText: 'Role'),
                      items: UserRole.values.where((e) => e != UserRole.admin).map((e) => DropdownMenuItem(value: e, child: Text(e.label))).toList(),
                      onChanged: (value) => setState(() => role = value ?? UserRole.buyer),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: DropdownButtonFormField<CountryOption>(
                            value: country,
                            decoration: const InputDecoration(labelText: 'Country'),
                            items: AppUtils.countries.map((item) => DropdownMenuItem(value: item, child: Text('${item.isoCode} ${item.dialCode}'))).toList(),
                            onChanged: (value) {
                              if (value == null) return;
                              setState(() {
                                country = value;
                                phone.value = TextEditingValue(text: country.dialCode, selection: TextSelection.collapsed(offset: country.dialCode.length));
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 3,
                          child: TextFormField(
                            controller: phone,
                            keyboardType: TextInputType.phone,
                            inputFormatters: [PhoneFormatter(country)],
                            decoration: InputDecoration(labelText: 'Phone', hintText: '${country.dialCode} ${country.example}'),
                            validator: (value) {
                              final digits = AppUtils.cleanPhone(value ?? '');
                              if (digits.length < 7) return 'Enter a valid phone number';
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: password,
                      obscureText: hidePassword,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        suffixIcon: IconButton(onPressed: () => setState(() => hidePassword = !hidePassword), icon: Icon(hidePassword ? Icons.visibility_off : Icons.visibility)),
                      ),
                      validator: AppUtils.password,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: confirmPassword,
                      obscureText: hideConfirmPassword,
                      decoration: InputDecoration(
                        labelText: 'Confirm password',
                        suffixIcon: IconButton(onPressed: () => setState(() => hideConfirmPassword = !hideConfirmPassword), icon: Icon(hideConfirmPassword ? Icons.visibility_off : Icons.visibility)),
                      ),
                      validator: (value) => value != password.text ? 'Passwords do not match' : null,
                    ),
                    if (appState.authError != null) ...[
                      const SizedBox(height: 12),
                      Text(appState.authError!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                    ],
                    const SizedBox(height: 18),
                    FilledButton(
                      onPressed: appState.authBusy
                          ? null
                          : () async {
                              if (!formKey.currentState!.validate()) return;
                              try {
                                await ref.read(appStateProvider).register(
                                      fullName: fullName.text.trim(),
                                      email: email.text.trim(),
                                      password: password.text,
                                      phone: phone.text.trim(),
                                      countryCode: country.isoCode,
                                      role: role,
                                    );
                                if (!mounted) return;
                                context.go('/app/home');
                              } catch (_) {}
                            },
                      child: Text(appState.authBusy ? 'Please wait...' : 'Create account'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class RoleSelectionScreen extends ConsumerWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('Choose your role')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: GridView.count(
            crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            children: UserRole.values.where((role) => role != UserRole.admin).map((role) => Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(24),
                onTap: () async {
                  await ref.read(appStateProvider).saveRole(role);
                  if (context.mounted) context.go('/app/home');
                },
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(child: Icon(_roleIcon(role))),
                      const Spacer(),
                      Text(role.label, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      const Text('Saved locally and in Firebase profile when available.'),
                    ],
                  ),
                ),
              ),
            )).toList(),
          ),
        ),
      );
}

class AppShellScreen extends StatelessWidget {
  const AppShellScreen({super.key, required this.shell});
  final StatefulNavigationShell shell;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: shell,
        bottomNavigationBar: NavigationBar(
          selectedIndex: shell.currentIndex,
          onDestinationSelected: (index) => shell.goBranch(index, initialLocation: index == shell.currentIndex),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Market'),
            NavigationDestination(icon: Icon(Icons.badge_outlined), selectedIcon: Icon(Icons.badge), label: 'Directory'),
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Inbox'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
        floatingActionButton: shell.currentIndex == 1
            ? FloatingActionButton.extended(onPressed: () => context.push('/app/market/create'), icon: const Icon(Icons.add), label: const Text('New listing'))
            : shell.currentIndex == 3
                ? FloatingActionButton.extended(onPressed: () => context.go('/app/directory'), icon: const Icon(Icons.add_comment), label: const Text('Start chat'))
                : null,
      );
}

Widget infoChip(IconData icon, String label) => Chip(avatar: Icon(icon, size: 18), label: Text(label));
Widget metricCard(BuildContext context, String title, String value, IconData icon) => Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: Icon(icon)),
            const SizedBox(height: 14),
            Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(title),
          ],
        ),
      ),
    );

class HomeDashboardScreen extends ConsumerWidget {
  const HomeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(appStateProvider);
    final name = state.user?.fullName.split(' ').first ?? 'Builder';
    return Scaffold(
      appBar: AppBar(title: Text('Hi, $name')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Theme.of(context).colorScheme.primary, Theme.of(context).colorScheme.secondary]),
              borderRadius: BorderRadius.circular(28),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('University project demo, fully usable', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                const Text('Register, browse the directory, start chats, and manage property requests with a clean flow.', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    FilledButton.tonal(onPressed: () => context.go('/app/directory'), child: const Text('Open directory')),
                    FilledButton.tonal(onPressed: () => context.go('/app/inbox'), child: const Text('Open inbox')),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          GridView.count(
            crossAxisCount: MediaQuery.of(context).size.width > 900 ? 4 : 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            children: [
              metricCard(context, 'Active listings', '${MockData.listings.length}', Icons.domain_add_outlined),
              metricCard(context, 'Open requests', '${MockData.requests.length}', Icons.assignment_turned_in_outlined),
              metricCard(context, 'Directory users', '${state.directoryUsers.length}', Icons.people_outline),
              metricCard(context, 'Inbox chats', '${state.inboxThreads.length}', Icons.chat_bubble_outline_rounded),
            ],
          ),
          const SizedBox(height: 18),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              FilledButton.icon(onPressed: () => context.push('/app/market/create'), icon: const Icon(Icons.add_business), label: const Text('Create listing')),
              OutlinedButton.icon(onPressed: () => context.push('/app/requests/new'), icon: const Icon(Icons.assignment_add), label: const Text('New request')),
              OutlinedButton.icon(onPressed: () => context.push('/app/estimates'), icon: const Icon(Icons.calculate), label: const Text('Open calculators')),
            ],
          ),
        ],
      ),
    );
  }
}

class MarketScreen extends ConsumerWidget {
  const MarketScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(appStateProvider);
    final controller = ref.read(appStateProvider);
    final items = state.filteredListings;
    return Scaffold(
      appBar: AppBar(title: const Text('Marketplace')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search by title, city, or keyword'), onChanged: controller.setMarketQuery),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                DropdownMenu<ListingType?>(initialSelection: state.listingTypeFilter, label: const Text('Listing type'), dropdownMenuEntries: [const DropdownMenuEntry(value: null, label: 'All'), ...ListingType.values.map((e) => DropdownMenuEntry(value: e, label: e.label))], onSelected: controller.setListingTypeFilter),
                const SizedBox(width: 10),
                DropdownMenu<PropertyType?>(initialSelection: state.propertyTypeFilter, label: const Text('Property type'), dropdownMenuEntries: [const DropdownMenuEntry(value: null, label: 'All'), ...PropertyType.values.map((e) => DropdownMenuEntry(value: e, label: e.label))], onSelected: controller.setPropertyTypeFilter),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ...items.map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Card(
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => context.push('/app/market/listing/${item.id}'),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(height: 180, color: Theme.of(context).colorScheme.primaryContainer, child: const Center(child: Icon(Icons.apartment_rounded, size: 72))),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(item.title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                              const SizedBox(height: 8),
                              Wrap(spacing: 8, runSpacing: 8, children: [
                                infoChip(Icons.sell_outlined, item.listingType.label),
                                infoChip(Icons.home_work_outlined, item.propertyType.label),
                                infoChip(Icons.location_city_outlined, item.city),
                                infoChip(Icons.square_foot, AppUtils.sqft(item.areaSqFt)),
                              ]),
                              const SizedBox(height: 10),
                              Text(AppUtils.pkr(item.price), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}

class ListingDetailsScreen extends ConsumerWidget {
  const ListingDetailsScreen({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final item = ref.watch(appStateProvider).findListing(id);
    if (item == null) return const Scaffold(body: Center(child: Text('Listing not found')));
    return Scaffold(
      appBar: AppBar(title: const Text('Listing details')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(height: 220, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(28)), child: const Center(child: Icon(Icons.location_city_rounded, size: 100))),
          const SizedBox(height: 16),
          Text(item.title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Text(item.description),
          const SizedBox(height: 16),
          Wrap(spacing: 8, runSpacing: 8, children: [
            infoChip(Icons.sell_outlined, item.listingType.label),
            infoChip(Icons.home_work_outlined, item.propertyType.label),
            infoChip(Icons.location_on_outlined, item.city),
            infoChip(Icons.square_foot, AppUtils.sqft(item.areaSqFt)),
          ]),
          const SizedBox(height: 16),
          Card(child: ListTile(title: const Text('Quoted price'), subtitle: Text(item.status), trailing: Text(AppUtils.pkr(item.price), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)))),
          Card(child: ListTile(leading: const Icon(Icons.call_outlined), title: Text(item.contactPhone), subtitle: const Text('Tap to call'), onTap: () => launchUrl(Uri.parse('tel:${item.contactPhone}')))),
          Card(child: ListTile(leading: const Icon(Icons.email_outlined), title: Text(item.contactEmail), subtitle: const Text('Tap to email'), onTap: () => launchUrl(Uri.parse('mailto:${item.contactEmail}')))),
        ],
      ),
    );
  }
}

class CreateListingScreen extends ConsumerStatefulWidget {
  const CreateListingScreen({super.key});

  @override
  ConsumerState<CreateListingScreen> createState() => _CreateListingScreenState();
}

class _CreateListingScreenState extends ConsumerState<CreateListingScreen> {
  final formKey = GlobalKey<FormState>();
  final title = TextEditingController();
  final description = TextEditingController();
  final address = TextEditingController();
  final area = TextEditingController();
  final price = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  ListingType listingType = ListingType.buy;
  PropertyType propertyType = PropertyType.residential;
  String city = 'Lahore';

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Create listing')),
        body: Form(
          key: formKey,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              TextFormField(controller: title, decoration: const InputDecoration(labelText: 'Title'), validator: (v) => AppUtils.requiredField(v, 'Title')),
              const SizedBox(height: 12),
              TextFormField(controller: description, decoration: const InputDecoration(labelText: 'Description'), maxLines: 3, validator: (v) => AppUtils.requiredField(v, 'Description')),
              const SizedBox(height: 12),
              DropdownButtonFormField<ListingType>(value: listingType, items: ListingType.values.map((e) => DropdownMenuItem(value: e, child: Text(e.label))).toList(), onChanged: (v) => setState(() => listingType = v ?? listingType), decoration: const InputDecoration(labelText: 'Listing type')),
              const SizedBox(height: 12),
              DropdownButtonFormField<PropertyType>(value: propertyType, items: PropertyType.values.map((e) => DropdownMenuItem(value: e, child: Text(e.label))).toList(), onChanged: (v) => setState(() => propertyType = v ?? propertyType), decoration: const InputDecoration(labelText: 'Property type')),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(value: city, items: const ['Lahore', 'Karachi', 'Islamabad', 'Rawalpindi'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => city = v ?? city), decoration: const InputDecoration(labelText: 'City')),
              const SizedBox(height: 12),
              TextFormField(controller: address, decoration: const InputDecoration(labelText: 'Address'), validator: (v) => AppUtils.requiredField(v, 'Address')),
              const SizedBox(height: 12),
              TextFormField(controller: area, decoration: const InputDecoration(labelText: 'Area in sqft'), validator: (v) => AppUtils.number(v, 'Area')),
              const SizedBox(height: 12),
              TextFormField(controller: price, decoration: const InputDecoration(labelText: 'Price'), validator: (v) => AppUtils.number(v, 'Price')),
              const SizedBox(height: 12),
              TextFormField(controller: phone, decoration: const InputDecoration(labelText: 'Contact phone'), validator: (v) => AppUtils.requiredField(v, 'Contact phone')),
              const SizedBox(height: 12),
              TextFormField(controller: email, decoration: const InputDecoration(labelText: 'Contact email'), validator: AppUtils.email),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () {
                  if (!formKey.currentState!.validate()) return;
                  final listing = Listing(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    title: title.text.trim(),
                    description: description.text.trim(),
                    listingType: listingType,
                    propertyType: propertyType,
                    city: city,
                    address: address.text.trim(),
                    areaSqFt: double.parse(area.text),
                    price: double.parse(price.text),
                    currency: 'PKR',
                    contactPhone: phone.text.trim(),
                    contactEmail: email.text.trim(),
                    status: 'Active',
                    imageUrl: 'assets/images/property_1.png',
                    createdAt: DateTime.now(),
                  );
                  ref.read(appStateProvider).addListing(listing);
                  context.go('/app/market/listing/${listing.id}');
                },
                child: const Text('Submit listing'),
              ),
            ],
          ),
        ),
      );
}

class UserDirectoryScreen extends ConsumerWidget {
  const UserDirectoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(appStateProvider);
    final users = state.filteredDirectoryUsers.where((user) => user.id != state.currentUserId).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('User directory')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search by name, email, or phone'),
            onChanged: ref.read(appStateProvider).setDirectoryQuery,
          ),
          const SizedBox(height: 12),
          DropdownMenu<UserRole?>(
            initialSelection: state.directoryRoleFilter,
            label: const Text('Filter by role'),
            dropdownMenuEntries: [const DropdownMenuEntry(value: null, label: 'All'), ...UserRole.values.where((role) => role != UserRole.admin).map((role) => DropdownMenuEntry(value: role, label: role.label))],
            onSelected: ref.read(appStateProvider).setDirectoryRoleFilter,
          ),
          const SizedBox(height: 16),
          if (users.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text('No users found.')),
            ),
          ...users.map((contact) => Card(
                child: ExpansionTile(
                  leading: CircleAvatar(child: Icon(_roleIcon(contact.role))),
                  title: Text(contact.fullName),
                  subtitle: Text('${contact.role?.label ?? 'User'} • ${contact.email}'),
                  childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  children: [
                    Align(alignment: Alignment.centerLeft, child: Text('Phone: ${contact.phone}')),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        OutlinedButton.icon(onPressed: () => launchUrl(Uri.parse('mailto:${contact.email}')), icon: const Icon(Icons.email_outlined), label: const Text('Email')),
                        OutlinedButton.icon(onPressed: () => launchUrl(Uri.parse('tel:${contact.phone}')), icon: const Icon(Icons.call_outlined), label: const Text('Call')),
                        FilledButton.icon(
                          onPressed: () async {
                            final threadId = await ref.read(appStateProvider).openOrCreateChat(contact);
                            if (!context.mounted) return;
                            context.push('/chat/$threadId?title=${Uri.encodeComponent(contact.fullName)}');
                          },
                          icon: const Icon(Icons.chat_outlined),
                          label: const Text('Start chat'),
                        ),
                      ],
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

class InboxScreen extends ConsumerStatefulWidget {
  const InboxScreen({super.key});

  @override
  ConsumerState<InboxScreen> createState() => _InboxScreenState();
}

class _InboxScreenState extends ConsumerState<InboxScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.read(appStateProvider).loadInbox());
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(appStateProvider);
    final threads = state.inboxThreads;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inbox'),
        actions: [
          TextButton.icon(onPressed: () => context.go('/app/directory'), icon: const Icon(Icons.add_comment), label: const Text('Add chat')),
        ],
      ),
      body: threads.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.chat_bubble_outline_rounded, size: 72),
                    const SizedBox(height: 12),
                    const Text('No chats yet'),
                    const SizedBox(height: 12),
                    FilledButton(onPressed: () => context.go('/app/directory'), child: const Text('Start a chat')),
                  ],
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: threads.length,
              itemBuilder: (context, index) {
                final item = threads[index];
                return Card(
                  child: ListTile(
                    onTap: () => context.push('/chat/${item.id}?title=${Uri.encodeComponent(item.counterpartName)}'),
                    leading: CircleAvatar(child: Text(item.counterpartName.isNotEmpty ? item.counterpartName[0].toUpperCase() : '?')),
                    title: Text(item.counterpartName),
                    subtitle: Text(item.lastMessagePreview),
                    trailing: Text(TimeOfDay.fromDateTime(item.updatedAt).format(context)),
                  ),
                );
              },
            ),
    );
  }
}

class ChatThreadScreen extends ConsumerStatefulWidget {
  const ChatThreadScreen({super.key, required this.id, required this.title});
  final String id;
  final String title;

  @override
  ConsumerState<ChatThreadScreen> createState() => _ChatThreadScreenState();
}

class _ChatThreadScreenState extends ConsumerState<ChatThreadScreen> {
  final input = TextEditingController();

  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.read(appStateProvider).loadMessages(widget.id));
  }

  @override
  Widget build(BuildContext context) {
    final messages = ref.watch(appStateProvider).messages(widget.id);
    final myId = ref.watch(appStateProvider).currentUserId;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        children: [
          Expanded(
            child: messages.isEmpty
                ? const Center(child: Text('No messages yet'))
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final item = messages[index];
                      final mine = item.senderId == myId;
                      return Align(
                        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          constraints: const BoxConstraints(maxWidth: 320),
                          decoration: BoxDecoration(
                            color: mine ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Column(
                            crossAxisAlignment: mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                            children: [
                              Text(item.text),
                              const SizedBox(height: 4),
                              Text(TimeOfDay.fromDateTime(item.createdAt).format(context), style: Theme.of(context).textTheme.labelSmall),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Row(
                children: [
                  Expanded(child: TextField(controller: input, decoration: const InputDecoration(hintText: 'Write a message'))),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: () async {
                      final text = input.text.trim();
                      if (text.isEmpty) return;
                      await ref.read(appStateProvider).sendMessage(widget.id, text);
                      input.clear();
                    },
                    child: const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RequestsInboxScreen extends ConsumerWidget {
  const RequestsInboxScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('Requests inbox')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Row(
              children: [
                Expanded(child: Text('Project requests', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
                TextButton.icon(onPressed: () => context.push('/app/requests/new'), icon: const Icon(Icons.add), label: const Text('New')),
              ],
            ),
            const SizedBox(height: 12),
            ...MockData.requests.map(
              (item) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Card(
                  child: ListTile(
                    onTap: () => context.push('/app/requests/${item.id}'),
                    title: Text(item.projectTitle),
                    subtitle: Text('${item.city} • ${item.status.label}'),
                    trailing: Text(AppUtils.pkr(item.budget)),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
}

class NewRequestWizardScreen extends ConsumerStatefulWidget {
  const NewRequestWizardScreen({super.key});
  @override
  ConsumerState<NewRequestWizardScreen> createState() => _NewRequestWizardScreenState();
}

class _NewRequestWizardScreenState extends ConsumerState<NewRequestWizardScreen> {
  final formKey = GlobalKey<FormState>();
  final title = TextEditingController();
  final area = TextEditingController();
  final timeline = TextEditingController(text: '6 months');
  final budget = TextEditingController();
  final notes = TextEditingController();
  int step = 0;
  PropertyType propertyType = PropertyType.residential;
  String city = 'Lahore';
  QualityLevel quality = QualityLevel.standard;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('New request wizard')),
        body: Form(
          key: formKey,
          child: Stepper(
            currentStep: step,
            onStepContinue: () {
              if (step < 2) {
                setState(() => step += 1);
                return;
              }
              if (!formKey.currentState!.validate()) return;
              final request = RequestProject(
                id: DateTime.now().millisecondsSinceEpoch.toString(),
                projectTitle: title.text.trim(),
                propertyType: propertyType,
                city: city,
                areaSqFt: double.parse(area.text.trim()),
                qualityLevel: quality,
                timeline: timeline.text.trim(),
                budget: double.parse(budget.text.trim()),
                notes: notes.text.trim(),
                status: RequestStatus.submitted,
                createdAt: DateTime.now(),
              );
              ref.read(appStateProvider).addRequest(request);
              context.go('/app/requests/${request.id}');
            },
            onStepCancel: () {
              if (step > 0) setState(() => step -= 1);
            },
            steps: [
              Step(
                title: const Text('Project basics'),
                content: Column(
                  children: [
                    TextFormField(controller: title, decoration: const InputDecoration(labelText: 'Project title'), validator: (v) => AppUtils.requiredField(v, 'Project title')),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<PropertyType>(value: propertyType, items: PropertyType.values.map((e) => DropdownMenuItem(value: e, child: Text(e.label))).toList(), onChanged: (v) => setState(() => propertyType = v ?? propertyType), decoration: const InputDecoration(labelText: 'Property type')),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(value: city, items: const ['Lahore', 'Karachi', 'Islamabad', 'Rawalpindi'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => city = v ?? city), decoration: const InputDecoration(labelText: 'City')),
                  ],
                ),
              ),
              Step(
                title: const Text('Scope & quality'),
                content: Column(
                  children: [
                    TextFormField(controller: area, decoration: const InputDecoration(labelText: 'Area (sqft)'), validator: (v) => AppUtils.number(v, 'Area')),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<QualityLevel>(value: quality, items: QualityLevel.values.map((e) => DropdownMenuItem(value: e, child: Text(e.label))).toList(), onChanged: (v) => setState(() => quality = v ?? quality), decoration: const InputDecoration(labelText: 'Quality level')),
                    const SizedBox(height: 12),
                    TextFormField(controller: timeline, decoration: const InputDecoration(labelText: 'Timeline')),
                  ],
                ),
              ),
              Step(
                title: const Text('Budget & notes'),
                content: Column(
                  children: [
                    TextFormField(controller: budget, decoration: const InputDecoration(labelText: 'Budget'), validator: (v) => AppUtils.number(v, 'Budget')),
                    const SizedBox(height: 12),
                    TextFormField(controller: notes, decoration: const InputDecoration(labelText: 'Notes'), minLines: 3, maxLines: 4),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}

class RequestDetailsScreen extends ConsumerWidget {
  const RequestDetailsScreen({super.key, required this.id});
  final String id;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final item = ref.watch(appStateProvider).findRequest(id);
    if (item == null) return const Scaffold(body: Center(child: Text('Request not found')));
    return Scaffold(
      appBar: AppBar(title: const Text('Request details')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(item.projectTitle, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: [
            infoChip(Icons.home_work_outlined, item.propertyType.label),
            infoChip(Icons.location_on_outlined, item.city),
            infoChip(Icons.workspace_premium_outlined, item.qualityLevel.label),
            infoChip(Icons.schedule_outlined, item.timeline),
          ]),
          const SizedBox(height: 14),
          Card(child: ListTile(title: const Text('Budget'), trailing: Text(AppUtils.pkr(item.budget)))),
          Card(child: ListTile(title: const Text('Area'), trailing: Text(AppUtils.sqft(item.areaSqFt)))),
          Card(child: ListTile(title: const Text('Status'), trailing: Text(item.status.label))),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(item.notes.isEmpty ? 'No notes added.' : item.notes))),
        ],
      ),
    );
  }
}

class EstimatesSuiteScreen extends ConsumerStatefulWidget {
  const EstimatesSuiteScreen({super.key});
  @override
  ConsumerState<EstimatesSuiteScreen> createState() => _EstimatesSuiteScreenState();
}

class _EstimatesSuiteScreenState extends ConsumerState<EstimatesSuiteScreen> with SingleTickerProviderStateMixin {
  late final TabController tabs = TabController(length: 3, vsync: this);
  final cArea = TextEditingController(text: '2250');
  final cRate = TextEditingController(text: '4200');
  final location = TextEditingController(text: '1.1');
  final contingency = TextEditingController(text: '0.1');
  final permit = TextEditingController(text: '250000');
  QualityLevel quality = QualityLevel.standard;
  final mArea = TextEditingController(text: '2250');
  final mRate = TextEditingController(text: '13200');
  final rArea = TextEditingController(text: '1600');
  final rRate = TextEditingController(text: '115');

  @override
  Widget build(BuildContext context) {
    final area = double.tryParse(cArea.text) ?? 0;
    final baseRate = double.tryParse(cRate.text) ?? 0;
    final loc = double.tryParse(location.text) ?? 1;
    final conRate = double.tryParse(contingency.text) ?? 0;
    final permitFees = double.tryParse(permit.text) ?? 0;
    final base = area * baseRate;
    final adjusted = base * loc * quality.multiplier;
    final con = adjusted * conRate;
    final total = adjusted + con + permitFees;
    final market = (double.tryParse(mArea.text) ?? 0) * (double.tryParse(mRate.text) ?? 0);
    final rent = (double.tryParse(rArea.text) ?? 0) * (double.tryParse(rRate.text) ?? 0);
    return Scaffold(
      appBar: AppBar(title: const Text('Estimates suite'), bottom: TabBar(controller: tabs, tabs: const [Tab(text: 'Construction'), Tab(text: 'Market value'), Tab(text: 'Rent')])),
      body: TabBarView(
        controller: tabs,
        children: [
          ListView(
            padding: const EdgeInsets.all(20),
            children: [
              TextField(controller: cArea, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Area (sqft)')),
              const SizedBox(height: 10),
              TextField(controller: cRate, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Base rate / sqft')),
              const SizedBox(height: 10),
              TextField(controller: location, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Location multiplier')),
              const SizedBox(height: 10),
              DropdownButtonFormField<QualityLevel>(value: quality, items: QualityLevel.values.map((e) => DropdownMenuItem(value: e, child: Text(e.label))).toList(), onChanged: (v) => setState(() => quality = v ?? quality), decoration: const InputDecoration(labelText: 'Quality level')),
              const SizedBox(height: 10),
              TextField(controller: contingency, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Contingency rate')),
              const SizedBox(height: 10),
              TextField(controller: permit, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Permit fees')),
              const SizedBox(height: 14),
              Card(child: ListTile(title: const Text('Base'), trailing: Text(AppUtils.pkr(base)))),
              Card(child: ListTile(title: const Text('Adjusted'), trailing: Text(AppUtils.pkr(adjusted)))),
              Card(child: ListTile(title: const Text('Contingency'), trailing: Text(AppUtils.pkr(con)))),
              Card(child: ListTile(title: const Text('Permit fees'), trailing: Text(AppUtils.pkr(permitFees)))),
              Card(child: ListTile(title: const Text('Total'), trailing: Text(AppUtils.pkr(total)))),
            ],
          ),
          ListView(
            padding: const EdgeInsets.all(20),
            children: [
              TextField(controller: mArea, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Area (sqft)')),
              const SizedBox(height: 10),
              TextField(controller: mRate, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Market price / sqft')),
              const SizedBox(height: 14),
              Card(child: ListTile(title: const Text('Estimated market value'), trailing: Text(AppUtils.pkr(market)))),
            ],
          ),
          ListView(
            padding: const EdgeInsets.all(20),
            children: [
              TextField(controller: rArea, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Area (sqft)')),
              const SizedBox(height: 10),
              TextField(controller: rRate, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Rent / sqft / month')),
              const SizedBox(height: 14),
              Card(child: ListTile(title: const Text('Estimated monthly rent'), trailing: Text(AppUtils.pkr(rent)))),
            ],
          ),
        ],
      ),
    );
  }
}

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(appStateProvider).user;
    final firebaseReady = ref.watch(appStateProvider).firebaseReady;
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: ListTile(
              leading: const CircleAvatar(radius: 28, child: Icon(Icons.person)),
              title: Text(user?.fullName ?? 'Guest'),
              subtitle: Text('${user?.email ?? '-'}\n${user?.phone ?? '-'}\nRole: ${user?.role?.label ?? 'Not selected'}'),
              isThreeLine: true,
            ),
          ),
          const SizedBox(height: 12),
          Card(child: ListTile(leading: const Icon(Icons.badge_outlined), title: const Text('User directory'), onTap: () => context.go('/app/directory'))),
          Card(child: ListTile(leading: const Icon(Icons.chat_outlined), title: const Text('Inbox'), onTap: () => context.go('/app/inbox'))),
          Card(child: ListTile(leading: const Icon(Icons.calculate_outlined), title: const Text('Estimators'), onTap: () => context.push('/app/estimates'))),
          Card(child: ListTile(leading: const Icon(Icons.assignment_outlined), title: const Text('Requests'), onTap: () => context.push('/app/requests'))),
          Card(child: ListTile(leading: const Icon(Icons.cloud_done_outlined), title: const Text('Firebase mode'), subtitle: Text(firebaseReady ? 'Active' : 'Local fallback active'))),
          const SizedBox(height: 12),
          FilledButton.tonal(onPressed: () async { await ref.read(appStateProvider).logout(); if (context.mounted) context.go('/login'); }, child: const Text('Logout')),
        ],
      ),
    );
  }
}

IconData _roleIcon(UserRole? role) {
  switch (role) {
    case UserRole.buyer:
      return Icons.shopping_bag_outlined;
    case UserRole.seller:
      return Icons.sell_outlined;
    case UserRole.renter:
      return Icons.key_outlined;
    case UserRole.contractor:
      return Icons.construction_outlined;
    case UserRole.agent:
      return Icons.real_estate_agent_outlined;
    case UserRole.admin:
      return Icons.admin_panel_settings_outlined;
    default:
      return Icons.person_outline;
  }
}
