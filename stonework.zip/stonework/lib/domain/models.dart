import 'package:flutter/material.dart';

const Duration kChatRetention = Duration(days: 7);

enum UserRole { buyer, seller, renter, contractor, agent, admin }
enum ListingType { buy, sell, rent, construct }
enum PropertyType { residential, commercial, apartment, building, road, land }
enum RequestStatus { draft, submitted, reviewing, quoted, approved, inProgress, completed }
enum QualityLevel { basic, standard, premium, luxury }

extension UserRoleX on UserRole {
  String get label => ['Buyer', 'Seller', 'Renter', 'Contractor', 'Agent', 'Admin'][index];
}

extension ListingTypeX on ListingType {
  String get label => ['Buy', 'Sell', 'Rent', 'Construct'][index];
}

extension PropertyTypeX on PropertyType {
  String get label => ['Residential', 'Commercial', 'Apartment', 'Building', 'Road', 'Land / Plot'][index];
}

extension RequestStatusX on RequestStatus {
  String get label => ['Draft', 'Submitted', 'Reviewing', 'Quoted', 'Approved', 'In Progress', 'Completed'][index];
}

extension QualityLevelX on QualityLevel {
  String get label => ['Basic', 'Standard', 'Premium', 'Luxury'][index];
  double get multiplier => [0.9, 1.0, 1.2, 1.45][index];
}

class CountryOption {
  final String isoCode;
  final String name;
  final String dialCode;
  final String example;

  const CountryOption({
    required this.isoCode,
    required this.name,
    required this.dialCode,
    required this.example,
  });
}

class AppUser {
  final String id;
  final String fullName;
  final String email;
  final String phone;
  final String countryCode;
  final UserRole? role;
  final bool onboardingSeen;
  final bool isPublicInDirectory;
  final DateTime? createdAt;

  const AppUser({
    required this.id,
    required this.fullName,
    required this.email,
    required this.phone,
    required this.countryCode,
    this.role,
    this.onboardingSeen = false,
    this.isPublicInDirectory = true,
    this.createdAt,
  });

  AppUser copyWith({
    String? id,
    String? fullName,
    String? email,
    String? phone,
    String? countryCode,
    UserRole? role,
    bool? onboardingSeen,
    bool? isPublicInDirectory,
    DateTime? createdAt,
  }) =>
      AppUser(
        id: id ?? this.id,
        fullName: fullName ?? this.fullName,
        email: email ?? this.email,
        phone: phone ?? this.phone,
        countryCode: countryCode ?? this.countryCode,
        role: role ?? this.role,
        onboardingSeen: onboardingSeen ?? this.onboardingSeen,
        isPublicInDirectory: isPublicInDirectory ?? this.isPublicInDirectory,
        createdAt: createdAt ?? this.createdAt,
      );

  Map<String, dynamic> toMap() => {
        'fullName': fullName,
        'email': email,
        'phone': phone,
        'countryCode': countryCode,
        'role': role?.name,
        'onboardingSeen': onboardingSeen,
        'isPublicInDirectory': isPublicInDirectory,
        'createdAt': (createdAt ?? DateTime.now()).toIso8601String(),
      };

  factory AppUser.fromMap(String id, Map<String, dynamic> map) {
    final roleName = map['role'] as String?;
    return AppUser(
      id: id,
      fullName: (map['fullName'] as String?) ?? '',
      email: (map['email'] as String?) ?? '',
      phone: (map['phone'] as String?) ?? '',
      countryCode: (map['countryCode'] as String?) ?? '',
      role: roleName == null ? null : UserRole.values.where((e) => e.name == roleName).firstOrNull,
      onboardingSeen: (map['onboardingSeen'] as bool?) ?? true,
      isPublicInDirectory: (map['isPublicInDirectory'] as bool?) ?? true,
      createdAt: DateTime.tryParse((map['createdAt'] as String?) ?? ''),
    );
  }
}

class Listing {
  final String id, title, description, city, address, currency, contactPhone, contactEmail, status, imageUrl;
  final ListingType listingType;
  final PropertyType propertyType;
  final double areaSqFt, price;
  final bool isFavorite;
  final DateTime createdAt;
  const Listing({required this.id, required this.title, required this.description, required this.listingType, required this.propertyType, required this.city, required this.address, required this.areaSqFt, required this.price, required this.currency, required this.contactPhone, required this.contactEmail, required this.status, required this.imageUrl, required this.createdAt, this.isFavorite = false});
  Listing copyWith({bool? isFavorite}) => Listing(id:id,title:title,description:description,listingType:listingType,propertyType:propertyType,city:city,address:address,areaSqFt:areaSqFt,price:price,currency:currency,contactPhone:contactPhone,contactEmail:contactEmail,status:status,imageUrl:imageUrl,createdAt:createdAt,isFavorite:isFavorite??this.isFavorite);
}

class RequestProject {
  final String id, projectTitle, city, timeline, notes;
  final PropertyType propertyType;
  final double areaSqFt, budget;
  final QualityLevel qualityLevel;
  final RequestStatus status;
  final DateTime createdAt;
  const RequestProject({required this.id, required this.projectTitle, required this.propertyType, required this.city, required this.areaSqFt, required this.qualityLevel, required this.timeline, required this.budget, required this.notes, required this.status, required this.createdAt});
}

class EstimateRecord {
  final String id, type;
  final double areaSqFt, result;
  final DateTime createdAt;
  final Map<String,double> breakdown;
  const EstimateRecord({required this.id, required this.type, required this.areaSqFt, required this.result, required this.createdAt, required this.breakdown});
}

class ChatThread {
  final String id;
  final String title;
  final String counterpartName;
  final String counterpartId;
  final String lastMessagePreview;
  final DateTime updatedAt;
  final DateTime expiresAt;
  final List<String> participantIds;

  const ChatThread({
    required this.id,
    required this.title,
    required this.counterpartName,
    required this.counterpartId,
    required this.lastMessagePreview,
    required this.updatedAt,
    required this.expiresAt,
    required this.participantIds,
  });

  Map<String, dynamic> toMap() => {
        'title': title,
        'counterpartName': counterpartName,
        'counterpartId': counterpartId,
        'lastMessagePreview': lastMessagePreview,
        'updatedAt': updatedAt.toIso8601String(),
        'expiresAt': expiresAt.toIso8601String(),
        'participantIds': participantIds,
      };

  factory ChatThread.fromMap(String id, Map<String, dynamic> map) => ChatThread(
        id: id,
        title: (map['title'] as String?) ?? 'Chat',
        counterpartName: (map['counterpartName'] as String?) ?? 'User',
        counterpartId: (map['counterpartId'] as String?) ?? '',
        lastMessagePreview: (map['lastMessagePreview'] as String?) ?? '',
        updatedAt: DateTime.tryParse((map['updatedAt'] as String?) ?? '') ?? DateTime.now(),
        expiresAt: DateTime.tryParse((map['expiresAt'] as String?) ?? '') ?? DateTime.now().add(kChatRetention),
        participantIds: ((map['participantIds'] as List?) ?? const []).cast<String>(),
      );
}

class ChatMessage {
  final String id, threadId, senderId, text;
  final DateTime createdAt;
  final DateTime expiresAt;
  const ChatMessage({required this.id, required this.threadId, required this.senderId, required this.text, required this.createdAt, required this.expiresAt});

  Map<String, dynamic> toMap() => {
        'threadId': threadId,
        'senderId': senderId,
        'text': text,
        'createdAt': createdAt.toIso8601String(),
        'expiresAt': expiresAt.toIso8601String(),
      };

  factory ChatMessage.fromMap(String id, Map<String, dynamic> map) => ChatMessage(
        id: id,
        threadId: (map['threadId'] as String?) ?? '',
        senderId: (map['senderId'] as String?) ?? '',
        text: (map['text'] as String?) ?? '',
        createdAt: DateTime.tryParse((map['createdAt'] as String?) ?? '') ?? DateTime.now(),
        expiresAt: DateTime.tryParse((map['expiresAt'] as String?) ?? '') ?? DateTime.now().add(kChatRetention),
      );
}

class AppPalette {
  static const seed = Color(0xFF9C6B30);
}

extension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
