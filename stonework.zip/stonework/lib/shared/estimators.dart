import '../domain/models.dart';

class ConstructionEstimateResult {
  final double base, adjusted, contingency, permitFees, total;
  const ConstructionEstimateResult({required this.base, required this.adjusted, required this.contingency, required this.permitFees, required this.total});
}

class Estimators {
  static ConstructionEstimateResult construction({required double areaSqFt, required double baseRatePerSqFt, required double locationMultiplier, required QualityLevel qualityLevel, required double contingencyRate, required double permitFees}) {
    final base = areaSqFt * baseRatePerSqFt;
    final adjusted = base * locationMultiplier * qualityLevel.multiplier;
    final contingency = adjusted * contingencyRate;
    final total = adjusted + contingency + permitFees;
    return ConstructionEstimateResult(base: base, adjusted: adjusted, contingency: contingency, permitFees: permitFees, total: total);
  }

  static double marketValue({required double areaSqFt, required double marketPricePerSqFt}) => areaSqFt * marketPricePerSqFt;
  static double rent({required double areaSqFt, required double rentPerSqFtMonthly}) => areaSqFt * rentPerSqFtMonthly;
}
