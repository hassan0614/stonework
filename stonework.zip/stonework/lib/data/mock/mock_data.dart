import '../../domain/models.dart';

class MockData {
  static AppUser user = AppUser(
    id: 'u1',
    fullName: 'Hassan Ali',
    email: 'hassan@example.com',
    phone: '+92 301 234 5678',
    countryCode: 'PK',
    role: UserRole.buyer,
    onboardingSeen: true,
    createdAt: DateTime.now(),
  );

  static List<AppUser> directoryUsers = [
    user,
    AppUser(id: 'u2', fullName: 'Areeba Khan', email: 'areeba@stonework.app', phone: '+92 300 111 2222', countryCode: 'PK', role: UserRole.agent, onboardingSeen: true, createdAt: DateTime.now()),
    AppUser(id: 'u3', fullName: 'Bilal Ahmed', email: 'bilal@stonework.app', phone: '+92 321 555 7777', countryCode: 'PK', role: UserRole.contractor, onboardingSeen: true, createdAt: DateTime.now()),
    AppUser(id: 'u4', fullName: 'Sara Malik', email: 'sara@stonework.app', phone: '+971 50 123 4567', countryCode: 'AE', role: UserRole.seller, onboardingSeen: true, createdAt: DateTime.now()),
    AppUser(id: 'u5', fullName: 'Usman Traders', email: 'usman@stonework.app', phone: '+92 333 444 5555', countryCode: 'PK', role: UserRole.renter, onboardingSeen: true, createdAt: DateTime.now()),
  ];

  static List<Listing> listings = [
    Listing(id: 'l1', title: 'Modern 5 Marla House in DHA', description: 'Premium home with lawn, parking, and strong resale value.', listingType: ListingType.buy, propertyType: PropertyType.residential, city: 'Lahore', address: 'DHA Phase 6', areaSqFt: 2250, price: 28500000, currency: 'PKR', contactPhone: '+92 300 1111111', contactEmail: 'agent1@stonework.app', status: 'Active', imageUrl: 'assets/images/property_1.png', createdAt: DateTime.now()),
    Listing(id: 'l2', title: 'Commercial Plaza Corner Plot', description: 'Ideal for offices, retail, and mixed-use development.', listingType: ListingType.sell, propertyType: PropertyType.commercial, city: 'Karachi', address: 'Gulshan-e-Iqbal', areaSqFt: 6800, price: 90000000, currency: 'PKR', contactPhone: '+92 300 2222222', contactEmail: 'sales@stonework.app', status: 'Negotiable', imageUrl: 'assets/images/property_2.png', createdAt: DateTime.now(), isFavorite: true),
    Listing(id: 'l3', title: 'Luxury Apartment for Rent', description: 'Serviced 3-bed apartment with city view.', listingType: ListingType.rent, propertyType: PropertyType.apartment, city: 'Islamabad', address: 'F-11 Markaz', areaSqFt: 1600, price: 185000, currency: 'PKR', contactPhone: '+92 300 3333333', contactEmail: 'rentals@stonework.app', status: 'Available', imageUrl: 'assets/images/property_3.png', createdAt: DateTime.now()),
    Listing(id: 'l4', title: 'Road Construction Tender Support', description: 'Experienced contractor setup for road development and oversight.', listingType: ListingType.construct, propertyType: PropertyType.road, city: 'Rawalpindi', address: 'Ring Road Zone', areaSqFt: 120000, price: 250000000, currency: 'PKR', contactPhone: '+92 300 4444444', contactEmail: 'projects@stonework.app', status: 'Open for bidding', imageUrl: 'assets/images/property_4.png', createdAt: DateTime.now()),
  ];

  static List<RequestProject> requests = [
    RequestProject(id: 'r1', projectTitle: '10 Marla Grey Structure', propertyType: PropertyType.residential, city: 'Lahore', areaSqFt: 3400, qualityLevel: QualityLevel.standard, timeline: '8 months', budget: 17000000, notes: 'Need full grey structure estimate and schedule.', status: RequestStatus.reviewing, createdAt: DateTime.now()),
    RequestProject(id: 'r2', projectTitle: 'Retail Plaza Renovation', propertyType: PropertyType.commercial, city: 'Karachi', areaSqFt: 5200, qualityLevel: QualityLevel.premium, timeline: '5 months', budget: 28000000, notes: 'Facade redesign, MEP upgrades, and fit-out.', status: RequestStatus.quoted, createdAt: DateTime.now()),
  ];

  static List<ChatThread> threads = [
    ChatThread(id: 't1', title: 'DHA House Inquiry', counterpartName: 'Areeba Khan', counterpartId: 'u2', lastMessagePreview: 'We can schedule a visit tomorrow.', updatedAt: DateTime.now(), expiresAt: DateTime.now().add(kChatRetention), participantIds: const ['u1', 'u2']),
    ChatThread(id: 't2', title: 'Grey Structure Request', counterpartName: 'Bilal Ahmed', counterpartId: 'u3', lastMessagePreview: 'Sharing the revised cost break-up.', updatedAt: DateTime.now(), expiresAt: DateTime.now().add(kChatRetention), participantIds: const ['u1', 'u3']),
  ];

  static Map<String, List<ChatMessage>> messages = {
    't1': [
      ChatMessage(id: 'm1', threadId: 't1', senderId: 'u2', text: 'Assalamualaikum! Thanks for your interest.', createdAt: DateTime.now(), expiresAt: DateTime.now().add(kChatRetention)),
      ChatMessage(id: 'm2', threadId: 't1', senderId: 'u1', text: 'Can I visit the property this week?', createdAt: DateTime.now(), expiresAt: DateTime.now().add(kChatRetention)),
      ChatMessage(id: 'm3', threadId: 't1', senderId: 'u2', text: 'We can schedule a visit tomorrow.', createdAt: DateTime.now(), expiresAt: DateTime.now().add(kChatRetention)),
    ],
    't2': [
      ChatMessage(id: 'm4', threadId: 't2', senderId: 'u3', text: 'Initial quote is ready for your review.', createdAt: DateTime.now(), expiresAt: DateTime.now().add(kChatRetention)),
      ChatMessage(id: 'm5', threadId: 't2', senderId: 'u1', text: 'Please include premium finishing as an option.', createdAt: DateTime.now(), expiresAt: DateTime.now().add(kChatRetention)),
    ]
  };
}
