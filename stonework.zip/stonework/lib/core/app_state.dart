import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../data/mock/mock_data.dart';
import '../domain/models.dart';

class AppState extends ChangeNotifier {
  AppUser? user;
  bool initialized = false;
  bool authBusy = false;
  String? authError;

  String marketQuery = '';
  ListingType? listingTypeFilter;
  PropertyType? propertyTypeFilter;
  String? cityFilter;

  String directoryQuery = '';
  UserRole? directoryRoleFilter;
  final List<AppUser> directoryUsers = [];
  final List<ChatThread> inboxThreads = [];
  final Map<String, List<ChatMessage>> _messages = {};
  final List<EstimateRecord> savedEstimates = [];

  bool get firebaseReady => Firebase.apps.isNotEmpty;
  String get currentUserId => user?.id ?? 'guest';
  bool get isLoggedIn => user != null && user!.id != 'guest';

  Future<void> init() async {
    if (initialized) return;
    await Future.delayed(const Duration(milliseconds: 900));
    final prefs = await SharedPreferences.getInstance();
    final onboardingSeen = prefs.getBool('onboarding_seen') ?? false;

    AppUser? resolvedUser;
    if (firebaseReady && FirebaseAuth.instance.currentUser != null) {
      try {
        resolvedUser = await _loadFirebaseUser(FirebaseAuth.instance.currentUser!.uid);
      } catch (_) {}
    }

    if (resolvedUser == null) {
      final loggedIn = prefs.getBool('logged_in') ?? false;
      if (loggedIn) {
        resolvedUser = AppUser(
          id: prefs.getString('uid') ?? MockData.user.id,
          fullName: prefs.getString('full_name') ?? MockData.user.fullName,
          email: prefs.getString('email') ?? MockData.user.email,
          phone: prefs.getString('phone') ?? MockData.user.phone,
          countryCode: prefs.getString('country_code') ?? 'PK',
          role: _roleFromName(prefs.getString('role')) ?? MockData.user.role,
          onboardingSeen: onboardingSeen,
          createdAt: DateTime.now(),
        );
      }
    }

    user = resolvedUser ?? AppUser(
      id: 'guest',
      fullName: 'Guest',
      email: 'guest@local.dev',
      phone: '+92',
      countryCode: 'PK',
      onboardingSeen: onboardingSeen,
    );

    initialized = true;
    await loadDirectoryUsers();
    await loadInbox();
    notifyListeners();
  }

  Future<void> markOnboardingSeen() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarding_seen', true);
    user = (user ?? const AppUser(id: 'guest', fullName: 'Guest', email: 'guest@local.dev', phone: '+92', countryCode: 'PK')).copyWith(onboardingSeen: true);
    if (firebaseReady && isLoggedIn) {
      try {
        await FirebaseFirestore.instance.collection('users').doc(user!.id).set({'onboardingSeen': true}, SetOptions(merge: true));
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    authBusy = true;
    authError = null;
    notifyListeners();
    try {
      AppUser logged;
      if (firebaseReady) {
        final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.trim(), password: password).timeout(const Duration(seconds: 30));
        logged = await _loadFirebaseUser(credential.user!.uid) ?? await _bootstrapFirebaseProfile(credential.user!, role: UserRole.buyer, fullName: credential.user!.displayName ?? 'Stone Work User', phone: '+92', countryCode: 'PK');
      } else {
        logged = MockData.directoryUsers.firstWhere(
          (e) => e.email.toLowerCase() == email.trim().toLowerCase(),
          orElse: () => MockData.user,
        );
      }
      user = logged.copyWith(onboardingSeen: true);
      await _persistUser(user!);
      await loadDirectoryUsers();
      await loadInbox();
    } on FirebaseAuthException catch (e) {
      authError = _mapAuthError(e);
      rethrow;
    } on TimeoutException {
      authError = 'Login timed out. Please check your internet connection.';
      rethrow;
    } catch (_) {
      authError = 'Unable to log in right now. Please try again.';
      rethrow;
    } finally {
      authBusy = false;
      notifyListeners();
    }
  }

  Future<void> register({
    required String fullName,
    required String email,
    required String password,
    required String phone,
    required String countryCode,
    required UserRole role,
  }) async {
    authBusy = true;
    authError = null;
    notifyListeners();

    try {
      final normalizedEmail = email.trim().toLowerCase();
      AppUser created;
      if (firebaseReady) {
        final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: normalizedEmail, password: password).timeout(const Duration(seconds: 30));
        await credential.user?.updateDisplayName(fullName.trim());
        created = await _bootstrapFirebaseProfile(credential.user!, role: role, fullName: fullName.trim(), phone: phone, countryCode: countryCode);
      } else {
        created = AppUser(
          id: const Uuid().v4(),
          fullName: fullName.trim(),
          email: normalizedEmail,
          phone: phone,
          countryCode: countryCode,
          role: role,
          onboardingSeen: true,
          createdAt: DateTime.now(),
        );
        MockData.user = created;
        MockData.directoryUsers.removeWhere((e) => e.email.toLowerCase() == normalizedEmail);
        MockData.directoryUsers.insert(0, created);
      }

      user = created.copyWith(onboardingSeen: true);
      await _persistUser(user!);
      await loadDirectoryUsers();
      await loadInbox();
    } on FirebaseAuthException catch (e) {
      authError = _mapAuthError(e);
      rethrow;
    } on FirebaseException catch (e) {
      authError = e.message ?? 'Database issue. Please verify Firestore is enabled.';
      rethrow;
    } on TimeoutException {
      authError = 'Registration timed out. Please check your internet or Firebase setup.';
      rethrow;
    } catch (_) {
      authError = 'Unable to register right now. Please try again.';
      rethrow;
    } finally {
      authBusy = false;
      notifyListeners();
    }
  }

  Future<void> saveRole(UserRole role) async {
    if (user == null) return;
    user = user!.copyWith(role: role);
    await _persistUser(user!);
    if (firebaseReady && isLoggedIn) {
      try {
        await FirebaseFirestore.instance.collection('users').doc(user!.id).set({'role': role.name}, SetOptions(merge: true));
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<void> logout() async {
    if (firebaseReady) {
      try {
        await FirebaseAuth.instance.signOut();
      } catch (_) {}
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('logged_in');
    await prefs.remove('uid');
    await prefs.remove('full_name');
    await prefs.remove('email');
    await prefs.remove('phone');
    await prefs.remove('country_code');
    await prefs.remove('role');
    final onboardingSeen = prefs.getBool('onboarding_seen') ?? true;
    user = AppUser(id: 'guest', fullName: 'Guest', email: 'guest@local.dev', phone: '+92', countryCode: 'PK', onboardingSeen: onboardingSeen);
    inboxThreads.clear();
    _messages.clear();
    await loadDirectoryUsers();
    notifyListeners();
  }

  Future<void> loadDirectoryUsers() async {
    if (firebaseReady) {
      try {
        final snap = await FirebaseFirestore.instance
            .collection('users')
            .where('isPublicInDirectory', isEqualTo: true)
            .get()
            .timeout(const Duration(seconds: 20));
        directoryUsers
          ..clear()
          ..addAll(snap.docs.map((doc) => AppUser.fromMap(doc.id, doc.data())).toList());
      } catch (_) {
        _seedLocalDirectory();
      }
    } else {
      _seedLocalDirectory();
    }
    notifyListeners();
  }

  List<AppUser> get filteredDirectoryUsers {
    final q = directoryQuery.trim().toLowerCase();
    return directoryUsers.where((user) {
      final matchesRole = directoryRoleFilter == null || user.role == directoryRoleFilter;
      final matchesText = q.isEmpty ||
          user.fullName.toLowerCase().contains(q) ||
          user.email.toLowerCase().contains(q) ||
          user.phone.toLowerCase().contains(q);
      return matchesRole && matchesText;
    }).toList();
  }

  void setDirectoryQuery(String value) {
    directoryQuery = value;
    notifyListeners();
  }

  void setDirectoryRoleFilter(UserRole? role) {
    directoryRoleFilter = role;
    notifyListeners();
  }

  Future<void> loadInbox() async {
    if (!isLoggedIn) {
      inboxThreads.clear();
      return;
    }
    await _cleanupExpiredChats();
    if (firebaseReady) {
      try {
        final snap = await FirebaseFirestore.instance
            .collection('threads')
            .where('participantIds', arrayContains: user!.id)
            .get()
            .timeout(const Duration(seconds: 20));
        final now = DateTime.now();
        inboxThreads
          ..clear()
          ..addAll(snap.docs
              .map((doc) => ChatThread.fromMap(doc.id, doc.data()))
              .where((thread) => thread.expiresAt.isAfter(now))
              .toList()
            ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt)));
      } catch (_) {
        _seedLocalInbox();
      }
    } else {
      _seedLocalInbox();
    }
    notifyListeners();
  }

  List<ChatMessage> messages(String threadId) {
    final now = DateTime.now();
    return List.of(_messages[threadId] ?? MockData.messages[threadId] ?? const [])
      ..removeWhere((e) => e.expiresAt.isBefore(now))
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
  }

  Future<void> loadMessages(String threadId) async {
    await _cleanupExpiredChats();
    if (firebaseReady) {
      try {
        final snap = await FirebaseFirestore.instance
            .collection('threads')
            .doc(threadId)
            .collection('messages')
            .get()
            .timeout(const Duration(seconds: 20));
        _messages[threadId] = snap.docs
            .map((doc) => ChatMessage.fromMap(doc.id, doc.data()))
            .where((msg) => msg.expiresAt.isAfter(DateTime.now()))
            .toList()
          ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      } catch (_) {
        _messages[threadId] = List.of(MockData.messages[threadId] ?? const []);
      }
    } else {
      _messages[threadId] = List.of(MockData.messages[threadId] ?? const []);
    }
    notifyListeners();
  }

  Future<String> openOrCreateChat(AppUser otherUser) async {
    if (!isLoggedIn) throw StateError('Please log in to start a chat.');
    await loadInbox();
    final existing = inboxThreads.where((thread) => thread.counterpartId == otherUser.id).firstOrNull;
    if (existing != null) return existing.id;

    final id = const Uuid().v4();
    final thread = ChatThread(
      id: id,
      title: 'Chat with ${otherUser.fullName}',
      counterpartName: otherUser.fullName,
      counterpartId: otherUser.id,
      lastMessagePreview: 'New conversation',
      updatedAt: DateTime.now(),
      expiresAt: DateTime.now().add(kChatRetention),
      participantIds: [user!.id, otherUser.id],
    );

    if (firebaseReady) {
      await FirebaseFirestore.instance.collection('threads').doc(id).set(thread.toMap());
    }
    inboxThreads.insert(0, thread);
    _messages[id] = [];
    notifyListeners();
    return id;
  }

  Future<void> sendMessage(String threadId, String text) async {
    if (!isLoggedIn) return;
    final message = ChatMessage(
      id: const Uuid().v4(),
      threadId: threadId,
      senderId: user!.id,
      text: text,
      createdAt: DateTime.now(),
      expiresAt: DateTime.now().add(kChatRetention),
    );

    _messages.putIfAbsent(threadId, () => []).add(message);
    final index = inboxThreads.indexWhere((e) => e.id == threadId);
    if (index >= 0) {
      final old = inboxThreads[index];
      inboxThreads[index] = ChatThread(
        id: old.id,
        title: old.title,
        counterpartName: old.counterpartName,
        counterpartId: old.counterpartId,
        lastMessagePreview: text,
        updatedAt: message.createdAt,
        expiresAt: message.expiresAt,
        participantIds: old.participantIds,
      );
    }
    inboxThreads.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    notifyListeners();

    if (firebaseReady) {
      await FirebaseFirestore.instance.collection('threads').doc(threadId).set({
        'lastMessagePreview': text,
        'updatedAt': message.createdAt.toIso8601String(),
        'expiresAt': message.expiresAt.toIso8601String(),
      }, SetOptions(merge: true));
      await FirebaseFirestore.instance.collection('threads').doc(threadId).collection('messages').doc(message.id).set(message.toMap());
    } else {
      MockData.messages.putIfAbsent(threadId, () => []).add(message);
    }
  }

  Future<void> _cleanupExpiredChats() async {
    final now = DateTime.now();
    inboxThreads.removeWhere((thread) => thread.expiresAt.isBefore(now));
    _messages.removeWhere((_, value) {
      value.removeWhere((msg) => msg.expiresAt.isBefore(now));
      return value.isEmpty;
    });

    if (firebaseReady && isLoggedIn) {
      try {
        final snap = await FirebaseFirestore.instance.collection('threads').where('participantIds', arrayContains: user!.id).get();
        for (final doc in snap.docs) {
          final thread = ChatThread.fromMap(doc.id, doc.data());
          if (thread.expiresAt.isBefore(now)) {
            final messages = await FirebaseFirestore.instance.collection('threads').doc(doc.id).collection('messages').get();
            for (final message in messages.docs) {
              await message.reference.delete();
            }
            await doc.reference.delete();
          }
        }
      } catch (_) {}
    }
  }

  List<Listing> get filteredListings => MockData.listings.where((item) {
    final q = marketQuery.toLowerCase();
    final qOk = q.isEmpty || item.title.toLowerCase().contains(q) || item.description.toLowerCase().contains(q) || item.city.toLowerCase().contains(q);
    final lOk = listingTypeFilter == null || item.listingType == listingTypeFilter;
    final pOk = propertyTypeFilter == null || item.propertyType == propertyTypeFilter;
    final cOk = cityFilter == null || cityFilter!.isEmpty || item.city == cityFilter;
    return qOk && lOk && pOk && cOk;
  }).toList();

  void setMarketQuery(String v) { marketQuery = v; notifyListeners(); }
  void setListingTypeFilter(ListingType? v) { listingTypeFilter = v; notifyListeners(); }
  void setPropertyTypeFilter(PropertyType? v) { propertyTypeFilter = v; notifyListeners(); }
  void setCityFilter(String? v) { cityFilter = v; notifyListeners(); }

  void toggleFavorite(String id) {
    final i = MockData.listings.indexWhere((e) => e.id == id);
    if (i >= 0) {
      MockData.listings[i] = MockData.listings[i].copyWith(isFavorite: !MockData.listings[i].isFavorite);
      notifyListeners();
    }
  }

  Listing? findListing(String id) => MockData.listings.where((e) => e.id == id).cast<Listing?>().firstWhere((e) => e != null, orElse: () => null);
  RequestProject? findRequest(String id) => MockData.requests.where((e) => e.id == id).cast<RequestProject?>().firstWhere((e) => e != null, orElse: () => null);

  void addListing(Listing listing) {
    MockData.listings.insert(0, listing);
    notifyListeners();
  }

  void addRequest(RequestProject request) {
    MockData.requests.insert(0, request);
    notifyListeners();
  }

  void saveEstimate(String type, double areaSqFt, double result, Map<String, double> breakdown) {
    savedEstimates.insert(0, EstimateRecord(id: const Uuid().v4(), type: type, areaSqFt: areaSqFt, result: result, createdAt: DateTime.now(), breakdown: breakdown));
    notifyListeners();
  }

  Future<void> _persistUser(AppUser appUser) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('logged_in', true);
    await prefs.setBool('onboarding_seen', true);
    await prefs.setString('uid', appUser.id);
    await prefs.setString('full_name', appUser.fullName);
    await prefs.setString('email', appUser.email);
    await prefs.setString('phone', appUser.phone);
    await prefs.setString('country_code', appUser.countryCode);
    if (appUser.role != null) {
      await prefs.setString('role', appUser.role!.name);
    }
  }

  Future<AppUser?> _loadFirebaseUser(String uid) async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get().timeout(const Duration(seconds: 20));
    if (doc.exists && doc.data() != null) {
      return AppUser.fromMap(doc.id, doc.data()!);
    }
    final authUser = FirebaseAuth.instance.currentUser;
    if (authUser != null) {
      return AppUser(
        id: uid,
        fullName: authUser.displayName ?? 'Stone Work User',
        email: authUser.email ?? '',
        phone: '+92',
        countryCode: 'PK',
        onboardingSeen: true,
        createdAt: DateTime.now(),
      );
    }
    return null;
  }

  Future<AppUser> _bootstrapFirebaseProfile(User firebaseUser, {required UserRole role, required String fullName, required String phone, required String countryCode}) async {
    final appUser = AppUser(
      id: firebaseUser.uid,
      fullName: fullName,
      email: firebaseUser.email ?? '',
      phone: phone,
      countryCode: countryCode,
      role: role,
      onboardingSeen: true,
      createdAt: DateTime.now(),
    );
    await FirebaseFirestore.instance.collection('users').doc(appUser.id).set(appUser.toMap(), SetOptions(merge: true)).timeout(const Duration(seconds: 30));
    return appUser;
  }

  void _seedLocalDirectory() {
    directoryUsers
      ..clear()
      ..addAll(MockData.directoryUsers);
  }

  void _seedLocalInbox() {
    final now = DateTime.now();
    inboxThreads
      ..clear()
      ..addAll(MockData.threads.where((thread) => thread.participantIds.contains(currentUserId) && thread.expiresAt.isAfter(now)));
    _messages
      ..clear()
      ..addAll(MockData.messages.map((key, value) => MapEntry(key, value.where((msg) => msg.expiresAt.isAfter(now)).toList())));
  }

  UserRole? _roleFromName(String? roleName) => UserRole.values.where((e) => e.name == roleName).firstOrNull;

  String _mapAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return 'This email is already registered.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'weak-password':
        return 'Password is too weak.';
      case 'invalid-credential':
      case 'wrong-password':
      case 'user-not-found':
        return 'Email or password is incorrect.';
      case 'network-request-failed':
        return 'Internet issue. Please check your connection.';
      default:
        return e.message ?? 'Authentication issue. Please try again.';
    }
  }
}

extension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}

final appStateProvider = ChangeNotifierProvider<AppState>((ref) {
  return AppState();
});
