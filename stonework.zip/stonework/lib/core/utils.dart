import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../domain/models.dart';

class AppUtils {
  static final _pkr = NumberFormat.currency(locale: 'en_PK', symbol: 'PKR ', decimalDigits: 0);
  static String pkr(num value) => _pkr.format(value);
  static String sqft(num value) => '${value.toStringAsFixed(0)} sqft';
  static String? requiredField(String? value, String name) => value == null || value.trim().isEmpty ? '$name is required' : null;
  static String? email(String? value) => (value == null || !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value.trim())) ? 'Enter a valid email' : null;
  static String? number(String? value, String name) {
    final parsed = double.tryParse((value ?? '').replaceAll(',', '').trim());
    if (parsed == null || parsed <= 0) return '$name must be a valid number';
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.length < 6) return 'Password must be at least 6 characters';
    return null;
  }

  static String cleanPhone(String value) => value.replaceAll(RegExp(r'\D'), '');

  static String formatPhone(CountryOption country, String rawDigits) {
    final digits = cleanPhone(rawDigits);
    if (digits.isEmpty) return country.dialCode;
    final groups = <int>[3, 3, 4, 4];
    final buffer = StringBuffer(country.dialCode);
    int index = 0;
    for (final length in groups) {
      if (index >= digits.length) break;
      final end = (index + length).clamp(0, digits.length);
      buffer.write(index == 0 ? ' ' : ' ');
      buffer.write(digits.substring(index, end));
      index = end;
    }
    if (index < digits.length) {
      buffer.write(' ');
      buffer.write(digits.substring(index));
    }
    return buffer.toString();
  }

  static List<CountryOption> get countries => const [
        CountryOption(isoCode: 'PK', name: 'Pakistan', dialCode: '+92', example: '300 123 4567'),
        CountryOption(isoCode: 'IN', name: 'India', dialCode: '+91', example: '98765 43210'),
        CountryOption(isoCode: 'BD', name: 'Bangladesh', dialCode: '+880', example: '1712 345678'),
        CountryOption(isoCode: 'AE', name: 'United Arab Emirates', dialCode: '+971', example: '50 123 4567'),
        CountryOption(isoCode: 'SA', name: 'Saudi Arabia', dialCode: '+966', example: '50 123 4567'),
        CountryOption(isoCode: 'QA', name: 'Qatar', dialCode: '+974', example: '3312 3456'),
        CountryOption(isoCode: 'KW', name: 'Kuwait', dialCode: '+965', example: '5000 1234'),
        CountryOption(isoCode: 'OM', name: 'Oman', dialCode: '+968', example: '9123 4567'),
        CountryOption(isoCode: 'BH', name: 'Bahrain', dialCode: '+973', example: '3600 1234'),
        CountryOption(isoCode: 'US', name: 'United States', dialCode: '+1', example: '201 555 0123'),
        CountryOption(isoCode: 'CA', name: 'Canada', dialCode: '+1', example: '416 555 0199'),
        CountryOption(isoCode: 'GB', name: 'United Kingdom', dialCode: '+44', example: '7400 123456'),
        CountryOption(isoCode: 'DE', name: 'Germany', dialCode: '+49', example: '1512 3456789'),
        CountryOption(isoCode: 'FR', name: 'France', dialCode: '+33', example: '6 12 34 56 78'),
        CountryOption(isoCode: 'IT', name: 'Italy', dialCode: '+39', example: '312 345 6789'),
        CountryOption(isoCode: 'ES', name: 'Spain', dialCode: '+34', example: '612 34 56 78'),
        CountryOption(isoCode: 'TR', name: 'Turkey', dialCode: '+90', example: '532 123 4567'),
        CountryOption(isoCode: 'CN', name: 'China', dialCode: '+86', example: '131 2345 6789'),
        CountryOption(isoCode: 'JP', name: 'Japan', dialCode: '+81', example: '90 1234 5678'),
        CountryOption(isoCode: 'KR', name: 'South Korea', dialCode: '+82', example: '10 1234 5678'),
        CountryOption(isoCode: 'MY', name: 'Malaysia', dialCode: '+60', example: '12 345 6789'),
        CountryOption(isoCode: 'SG', name: 'Singapore', dialCode: '+65', example: '8123 4567'),
        CountryOption(isoCode: 'TH', name: 'Thailand', dialCode: '+66', example: '81 234 5678'),
        CountryOption(isoCode: 'ID', name: 'Indonesia', dialCode: '+62', example: '812 3456 7890'),
        CountryOption(isoCode: 'AU', name: 'Australia', dialCode: '+61', example: '412 345 678'),
        CountryOption(isoCode: 'NZ', name: 'New Zealand', dialCode: '+64', example: '21 123 4567'),
        CountryOption(isoCode: 'ZA', name: 'South Africa', dialCode: '+27', example: '71 123 4567'),
        CountryOption(isoCode: 'NG', name: 'Nigeria', dialCode: '+234', example: '801 234 5678'),
        CountryOption(isoCode: 'EG', name: 'Egypt', dialCode: '+20', example: '100 123 4567'),
        CountryOption(isoCode: 'KE', name: 'Kenya', dialCode: '+254', example: '712 345678'),
        CountryOption(isoCode: 'BR', name: 'Brazil', dialCode: '+55', example: '11 91234 5678'),
        CountryOption(isoCode: 'MX', name: 'Mexico', dialCode: '+52', example: '55 1234 5678'),
        CountryOption(isoCode: 'AR', name: 'Argentina', dialCode: '+54', example: '11 2345 6789'),
      ];

  static CountryOption countryFromIso(String? isoCode) =>
      countries.where((e) => e.isoCode == isoCode).firstOrNull ?? countries.first;
}

class PhoneFormatter extends TextInputFormatter {
  PhoneFormatter(this.country);
  final CountryOption country;

  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final digits = AppUtils.cleanPhone(newValue.text.replaceFirst(country.dialCode, ''));
    final formatted = AppUtils.formatPhone(country, digits);
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }
}

extension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
