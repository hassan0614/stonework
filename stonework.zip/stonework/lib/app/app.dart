import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../core/app_state.dart';
import '../domain/models.dart';
import '../features/screens.dart';

class StoneworkApp extends ConsumerStatefulWidget {
  const StoneworkApp({super.key});

  @override
  ConsumerState<StoneworkApp> createState() => _StoneworkAppState();
}

class _StoneworkAppState extends ConsumerState<StoneworkApp> {
  late final GoRouter _router;

  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.read(appStateProvider).init());
    _router = GoRouter(
      refreshListenable: ref.read(appStateProvider),
      initialLocation: '/',
      redirect: (context, state) {
        final appState = ref.read(appStateProvider);
        final path = state.uri.path;

        if (!appState.initialized) return path == '/' ? null : '/';

        final onboardingSeen = appState.user?.onboardingSeen ?? false;
        final loggedIn = appState.isLoggedIn;
        final roleSelected = appState.user?.role != null;

        if (path == '/') {
          if (!onboardingSeen) return '/onboarding';
          if (!loggedIn) return '/login';
          if (!roleSelected) return '/role';
          return '/app/home';
        }

        if (!onboardingSeen && path != '/onboarding' && path != '/login' && path != '/register') {
          return '/onboarding';
        }

        if (!loggedIn && !['/login', '/register', '/onboarding'].contains(path)) {
          return '/login';
        }

        if (loggedIn && !roleSelected && path != '/role') {
          return '/role';
        }

        if (loggedIn && roleSelected && ['/login', '/register', '/role', '/onboarding'].contains(path)) {
          return '/app/home';
        }

        return null;
      },
      routes: [
        GoRoute(path: '/', builder: (c, s) => const SplashGateScreen()),
        GoRoute(path: '/onboarding', builder: (c, s) => const OnboardingScreen()),
        GoRoute(path: '/login', builder: (c, s) => const LoginScreen()),
        GoRoute(path: '/register', builder: (c, s) => const RegisterScreen()),
        GoRoute(path: '/role', builder: (c, s) => const RoleSelectionScreen()),
        StatefulShellRoute.indexedStack(
          builder: (context, state, navigationShell) => AppShellScreen(shell: navigationShell),
          branches: [
            StatefulShellBranch(routes: [GoRoute(path: '/app/home', builder: (c, s) => const HomeDashboardScreen())]),
            StatefulShellBranch(routes: [
              GoRoute(
                path: '/app/market',
                builder: (c, s) => const MarketScreen(),
                routes: [
                  GoRoute(path: 'listing/:id', builder: (c, s) => ListingDetailsScreen(id: s.pathParameters['id']!)),
                  GoRoute(path: 'create', builder: (c, s) => const CreateListingScreen()),
                ],
              ),
            ]),
            StatefulShellBranch(routes: [GoRoute(path: '/app/directory', builder: (c, s) => const UserDirectoryScreen())]),
            StatefulShellBranch(routes: [GoRoute(path: '/app/inbox', builder: (c, s) => const InboxScreen())]),
            StatefulShellBranch(routes: [GoRoute(path: '/app/profile', builder: (c, s) => const ProfileScreen())]),
          ],
        ),
        GoRoute(path: '/app/requests', builder: (c, s) => const RequestsInboxScreen(), routes: [
          GoRoute(path: 'new', builder: (c, s) => const NewRequestWizardScreen()),
          GoRoute(path: ':id', builder: (c, s) => RequestDetailsScreen(id: s.pathParameters['id']!)),
        ]),
        GoRoute(path: '/app/estimates', builder: (c, s) => const EstimatesSuiteScreen()),
        GoRoute(path: '/chat/:id', builder: (c, s) => ChatThreadScreen(id: s.pathParameters['id']!, title: s.uri.queryParameters['title'] ?? 'Chat')),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(seedColor: AppPalette.seed);
    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'Stone Work Construction',
      routerConfig: _router,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: const Color(0xFFF6F4EF),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.transparent,
          foregroundColor: scheme.onSurface,
          elevation: 0,
          centerTitle: false,
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: scheme.outlineVariant),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: scheme.outlineVariant),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: scheme.primary, width: 1.5),
          ),
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          elevation: 0.5,
        ),
      ),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('en')],
    );
  }
}
