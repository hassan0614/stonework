Placeholder iOS host folder. Run `flutter create . --platforms=ios` if you want Flutter to regenerate standard host files.
