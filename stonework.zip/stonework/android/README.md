Placeholder Android host folder. Run `flutter create . --platforms=android` if you want Flutter to regenerate standard host files.
