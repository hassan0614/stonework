import 'package:flutter_test/flutter_test.dart';
import 'package:stonework_construction/domain/models.dart';
import 'package:stonework_construction/shared/estimators.dart';

void main() {
  test('construction estimate formula works', () {
    final result = Estimators.construction(areaSqFt: 1000, baseRatePerSqFt: 4000, locationMultiplier: 1.1, qualityLevel: QualityLevel.standard, contingencyRate: 0.1, permitFees: 200000);
    expect(result.base, 4000000);
    expect(result.adjusted, 4400000);
    expect(result.contingency, 440000);
    expect(result.total, 5040000);
  });

  test('market value formula works', () {
    expect(Estimators.marketValue(areaSqFt: 1000, marketPricePerSqFt: 12000), 12000000);
  });

  test('rent formula works', () {
    expect(Estimators.rent(areaSqFt: 1000, rentPerSqFtMonthly: 100), 100000);
  });
}
