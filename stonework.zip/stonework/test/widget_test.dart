import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:stonework_construction/features/screens.dart';

void main() {
  testWidgets('login screen renders', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: MaterialApp(home: LoginScreen())));
    expect(find.byKey(const Key('login_email')), findsOneWidget);
    expect(find.byKey(const Key('login_button')), findsOneWidget);
  });

  testWidgets('market screen renders search', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: MaterialApp(home: MarketScreen())));
    await tester.pump();
    expect(find.byKey(const Key('market_search')), findsOneWidget);
  });

  testWidgets('estimates screen shows tabs', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: MaterialApp(home: EstimatesSuiteScreen())));
    await tester.pump();
    expect(find.text('Construction'), findsOneWidget);
    expect(find.text('Market value'), findsOneWidget);
    expect(find.text('Rent'), findsOneWidget);
  });
}
